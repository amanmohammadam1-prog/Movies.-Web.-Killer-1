MOVIESMELA NETLIFY API FIX

This package contains:
- index.html
- netlify/functions/wp-proxy.js
- netlify.toml

IMPORTANT: A plain drag-and-drop upload of index.html is NOT enough for this version.
The Netlify Function must be deployed too.

DEPLOY:
1. Extract this ZIP on a computer, or on Android use an archive app that can extract ZIP files.
2. Upload the extracted project folder to a GitHub repository, keeping the exact folder structure.
3. In Netlify: Add new site -> Import an existing project -> choose that GitHub repository.
4. Build settings:
   Build command: leave blank
   Publish directory: .
   Functions directory: netlify/functions
   (netlify.toml already contains these settings.)
5. Deploy. Open the resulting HTTPS Netlify URL.

TEST:
Open YOUR-NETLIFY-URL/.netlify/functions/wp-proxy?path=posts&per_page=2&_embed=1
It should show JSON. Then open the home page; movie cards should load.

If the proxy test shows 404, the Netlify Function was not deployed or folder structure is wrong.
If it shows 502, Netlify cannot reach the source WordPress API.
If proxy JSON works but cards don't, send a screenshot and we will fix the frontend.

VIDEO:
- MP4 playback/download controls are for your own or licensed HTTPS MP4 files only.
- A local phone video is playable only on that phone; it is not uploaded to your site.
- The original API sample did not include a direct MP4 download URL. This project does not extract third-party copyrighted streams or create unauthorized download links.

// Netlify Function: safe proxy for the public MoviesMela WordPress REST API.
// Only posts, a single numeric post, and categories are allowed (prevents open-proxy abuse).
exports.handler = async function(event) {
  const params = event.queryStringParameters || {};
  const requestedPath = params.path || "";
  if (!/^(posts(?:\/\d+)?|categories)$/.test(requestedPath)) {
    return { statusCode: 400, headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ error: "Unsupported API path" }) };
  }

  const target = new URL("https://www.moviesmela.com/wp-json/wp/v2/" + requestedPath);
  const allowed = ["per_page", "page", "_embed", "orderby", "order", "hide_empty"];
  for (const key of allowed) {
    if (params[key] !== undefined) target.searchParams.set(key, params[key]);
  }

  try {
    const upstream = await fetch(target.toString(), {
      headers: { "Accept": "application/json", "User-Agent": "MoviesMela-Netlify-Proxy/1.0" }
    });
    const body = await upstream.text();
    return {
      statusCode: upstream.status,
      headers: {
        "Content-Type": upstream.headers.get("content-type") || "application/json; charset=utf-8",
        "Cache-Control": "public, max-age=60",
        "Access-Control-Allow-Origin": "*"
      },
      body
    };
  } catch (error) {
    return {
      statusCode: 502,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ error: "Could not reach the WordPress API", detail: String(error) })
    };
  }
};
